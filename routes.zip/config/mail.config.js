const mailConfig = {
	host: "smtp.ex.provati.com.bd",
	port: 465,
	secure: false, // true for 465, false for other ports
	auth: {
		user: "admin@ex.provati.com.bd",
		pass: "123asdASD!@#",
	},
};

module.exports = mailConfig;
